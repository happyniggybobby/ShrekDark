# ShrekDark

Quality of Life extension for [drednot.io game](https://drednot.io/)
<h3>Everything that should already be in the game... and more</h3>

<h3>Enhance your gaming experience </h3>

Customize your experience to your liking
For any questions, refer to this [discord server](https://discord.gg/EsxkNNX4rK)
Extension developed by I am Shrek - Kapi73#3815