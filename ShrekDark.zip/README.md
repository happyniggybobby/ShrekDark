# ShrekDark

Quality of Life extension for [drednot.io game](https://drednot.io/)
<h3>Everything that should already be in the game... and more</h3>

<h3>Enhance your gaming experience </h3>

Customize your experience to your liking
For any questions, refer to this [discord server](https://discord.gg/EsxkNNX4rK)
Extension developed by I am Shrek - Kapi73#3815

<h4>Chat Enhancements</h4>
<ul>
    <li>interactive invites with ship preview</li>
    <li>built-in translator</li>
    <li>click player name to manage him</li>
    <li>often used phrases</li>
    <li>missed messages marked red</li>
    <li>expandable height</li>
    <li>smooth animations</li>
    <li>player list ship under TAB key</li>
</ul>

<h4>Button Customizations</h4>
<ul>
    <li>new game buttons: rejoin, instant save, invite</li>
    <li>customizable buttons - text, color, visibility</li>
</ul>

<h4>User Interface</h4>
<ul>
    <li>modern game menu</li>
    <li>animations</li>
    <li>customizable UI color</li>
    <li>customizable scrollbars</li>
</ul>

<h4>Quality of Life</h4>
<ul>
    <li>Enhanced kicked out screen - time, rejoin, view chat</li>
    <li>hotkeys for crucial tasks - exit, gravity, save etc.</li>
    <li>toggle ' (cinematic mode) and / (stats)</li>
    <li>favourite ships</li>
    <li>snakecopter!</li>
    <li>save gravity diredction in ship</li>
    <li>quick Texture pack swap</li>
    <li>emergency distress ping for discord</li>
    <li>crew amount statistics</li>
</ul>